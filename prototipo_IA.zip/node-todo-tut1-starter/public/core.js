var scotchTodo = angular.module('scotchTodo', []);

function mainController($scope, $http, $timeout) {
	$scope.formData = {};
    $scope.csvData = {};
    $scope.displayChart = false;
    $scope.progressPredBar = false;
    $scope.progressPredWidth = 0;
    

	// when landing on the page, get all todos and show them
	// $http.get('/api/todos')
		// .success(function(data) {
			// $scope.todos = data;
		// })
		// .error(function(data) {
			// console.log('Error: ' + data);
		// });
        
    $scope.readTodo = function() {
        $http.get('/api/csv')
            .success(function(data) {
                $scope.csvData = data;
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
    };
	// when submitting the add form, send the text to the node API
	$scope.createTodo = function() {
        $scope.progressPredBar = true;
        
        $timeout( function(){
            $scope.progressPredBar = false;
            $scope.progressPredWidth = 0;
            $scope.displayChart = true;
            $http.post('/api/todos', $scope.formData)
                .success(function(data) {
                    $scope.formData = {}; // clear the form so our user is ready to enter another
                    $scope.todos = data;
                    console.log(data);
                })
                .error(function(data) {
                    console.log('Error: ' + data);
                });
        }, 5000 );
        
        //time
        $scope.time = 0;
        
        //timer callback
        var timer = function() {
            if( $scope.time < 5000 ) {
                $scope.time += 100;
                $scope.progressPredWidth = $scope.time/50;
                $timeout(timer, 100);
            }
        }
        
        //run!!
        $timeout(timer, 100);
        
        
	};

	// delete a todo after checking it
	// $scope.deleteTodo = function(id) {
		// $http.delete('/api/todos/' + id)
			// .success(function(data) {
				// $scope.todos = data;
			// })
			// .error(function(data) {
				// console.log('Error: ' + data);
			// });
	// };

}
